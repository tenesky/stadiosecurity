import 'dart:convert';

import 'package:mysql1/mysql1.dart';
import 'package:crypto/crypto.dart';
import 'dart:typed_data';
import 'package:http/http.dart' as http;
import 'dart:io';
// Note: we do not import path_provider here because the package may not be
// available by default.  Instead we save uploaded files into a local
// directory named `uploads` that sits alongside the `lib` and `assets`
// folders in the project root.  By writing directly into this folder
// relative to the application's current working directory we avoid
// introducing a dependency on `path_provider` while still giving the app
// a predictable location to persist user‑uploaded files.

/// Provides static methods for connecting to the MySQL database and
/// performing user related operations.  The connection settings
/// correspond to the environment described in the task description.
///
/// In a real world application you would avoid connecting directly
/// from a client and instead call a backend API.  This service
/// demonstrates a direct connection for educational purposes only.
class DbService {
  DbService._();

  /// Cache of locally saved map file paths keyed by map id.  When a plan
  /// or document is uploaded and persisted to disk, the returned relative
  /// path is recorded in this map alongside the newly created database
  /// record id.  During retrieval, [getStadiumMaps] consults this
  /// cache first to avoid hitting the database for the file location.
  ///
  /// This cache persists only for the lifetime of the application and
  /// is not written to disk.  It allows the UI to display previews of
  /// newly uploaded files immediately without needing to wait for a
  /// round trip to the database.  When the app restarts or when the
  /// cache does not contain an entry for a map id, the database value
  /// is used as a fallback.
  static final Map<int, String> _localMapPaths = {};

  /// Connection settings for the target MySQL server.  Adjust host,
  /// port, user and password if your environment changes.
  static final ConnectionSettings _settings = ConnectionSettings(
    host: '80.152.153.30',
    port: 3306,
    user: 'pss',
    password: 'psspassword',
    db: 'pss',
  );

  /// Establishes a new connection to the database.  Each call to
  /// [authenticate] obtains and closes its own connection to avoid
  /// leaving sockets open.
  static Future<MySqlConnection> _connect() async {
    return await MySqlConnection.connect(_settings);
  }

  /// Validates the supplied [username] and [password].  On success
  /// a map containing the user id, username and role name is
  /// returned.  On failure `null` is returned.
  static Future<Map<String, Object>?> authenticate(
      String username, String password) async {
    final conn = await _connect();
    try {
      // Look up user by name.
      final results = await conn.query(
        'SELECT id, username, password_hash, role_id FROM users WHERE username = ?',
        [username],
      );
      if (results.isEmpty) {
        return null;
      }
      final row = results.first;
      final String storedHash = row['password_hash'] as String;
      final String incomingHash = sha256.convert(utf8.encode(password)).toString();
      if (storedHash != incomingHash) {
        return null;
      }
      // Retrieve role name.
      final roleResults = await conn.query(
        'SELECT name FROM roles WHERE id = ?',
        [row['role_id']],
      );
      String roleName = roleResults.isNotEmpty
          ? (roleResults.first['name'] as String)
          : '';
      return {
        'id': row['id'] as int,
        'username': row['username'] as String,
        'role': roleName,
      };
    } finally {
      await conn.close();
    }
  }

  /// Creates a new user with the given parameters.  The password is
  /// hashed using SHA‑256 before it is stored.  Only administrators
  /// should call this method.  Returns the newly created user id.
  static Future<int> createUser({
    required String username,
    required String password,
    required int roleId,
  }) async {
    final conn = await _connect();
    try {
      final String hash = sha256.convert(utf8.encode(password)).toString();
      final result = await conn.query(
        'INSERT INTO users (username, password_hash, role_id) VALUES (?, ?, ?)',
        [username, hash, roleId],
      );
      return result.insertId ?? 0;
    } finally {
      await conn.close();
    }
  }

  /// Updates the password for a given user.  The new password will be
  /// hashed using SHA‑256.
  static Future<void> updatePassword({
    required int userId,
    required String newPassword,
  }) async {
    final conn = await _connect();
    try {
      final String hash = sha256.convert(utf8.encode(newPassword)).toString();
      await conn.query(
        'UPDATE users SET password_hash = ? WHERE id = ?',
        [hash, userId],
      );
    } finally {
      await conn.close();
    }
  }

  /// Retrieves all users along with their roles.  Each map in the
  /// returned list contains the keys: id, username, role_id and
  /// role_name (may be null if the user has no role).
  static Future<List<Map<String, dynamic>>> getUsersWithRoles() async {
    final conn = await _connect();
    try {
      final results = await conn.query(
        'SELECT users.id, users.username, users.role_id, roles.name AS role_name '
        'FROM users LEFT JOIN roles ON users.role_id = roles.id ORDER BY users.id',
      );
      final users = <Map<String, dynamic>>[];
      for (final row in results) {
        users.add({
          'id': row['id'] as int,
          'username': row['username'] as String,
          'role_id': row['role_id'] as int?,
          'role_name': row['role_name'] as String?,
        });
      }
      return users;
    } finally {
      await conn.close();
    }
  }

  /// Retrieves all roles.  Each map contains id, name and description.
  static Future<List<Map<String, dynamic>>> getRoles() async {
    final conn = await _connect();
    try {
      final results = await conn.query(
        'SELECT id, name, description FROM roles ORDER BY id',
      );
      final roles = <Map<String, dynamic>>[];
      for (final row in results) {
        roles.add({
          'id': row['id'] as int,
          'name': row['name'] as String,
          'description': row['description'] as String?,
        });
      }
      return roles;
    } finally {
      await conn.close();
    }
  }

  /// Updates a user's username and role.
  static Future<void> updateUser({
    required int userId,
    required String username,
    required int? roleId,
  }) async {
    final conn = await _connect();
    try {
      await conn.query(
        'UPDATE users SET username = ?, role_id = ? WHERE id = ?',
        [username, roleId, userId],
      );
    } finally {
      await conn.close();
    }
  }

  /// Deletes a user by id.
  static Future<void> deleteUser(int userId) async {
    final conn = await _connect();
    try {
      await conn.query('DELETE FROM users WHERE id = ?', [userId]);
    } finally {
      await conn.close();
    }
  }

  /// Creates a new role.  Returns the id of the newly created role.
  static Future<int> createRole({
    required String name,
    String? description,
  }) async {
    final conn = await _connect();
    try {
      final result = await conn.query(
        'INSERT INTO roles (name, description) VALUES (?, ?)',
        [name, description],
      );
      return result.insertId ?? 0;
    } finally {
      await conn.close();
    }
  }

  /// Updates an existing role's name and description.
  static Future<void> updateRole({
    required int roleId,
    required String name,
    String? description,
  }) async {
    final conn = await _connect();
    try {
      await conn.query(
        'UPDATE roles SET name = ?, description = ? WHERE id = ?',
        [name, description, roleId],
      );
    } finally {
      await conn.close();
    }
  }

  /// Deletes a role.  Note: you should reassign or null out role_ids on
  /// users before deleting a role to avoid foreign key constraints.
  static Future<void> deleteRole(int roleId) async {
    final conn = await _connect();
    try {
      await conn.query('DELETE FROM roles WHERE id = ?', [roleId]);
    } finally {
      await conn.close();
    }
  }

  // --------------------------------------------------------------------------
  // Stadium related methods

  /// Uploads a plan file to the configured PHP endpoint.  The file
  /// should be provided as a list of bytes and the original name.  On
  /// success, the server is expected to return a JSON object with a
  /// `url` field pointing to the saved file location.  Throws an
  /// exception if the upload fails.

  /// Retrieves all stadiums.  Each map contains id, name, address,
  /// default_leader, default_leader_phone, default_leader_email and default_club.
  static Future<List<Map<String, dynamic>>> getStadiums() async {
    final conn = await _connect();
    try {
      final results = await conn.query(
        'SELECT id, name, address, default_leader, default_leader_phone, default_leader_email, default_club FROM stadiums ORDER BY id',
      );
      final stadiums = <Map<String, dynamic>>[];
      for (final row in results) {
        stadiums.add({
          'id': row['id'] as int,
          'name': row['name'] as String,
          'address': row['address'] as String?,
          'default_leader': row['default_leader'] as String?,
          'default_leader_phone': row['default_leader_phone'] as String?,
          'default_leader_email': row['default_leader_email'] as String?,
          'default_club': row['default_club'] as String?,
        });
      }
      return stadiums;
    } finally {
      await conn.close();
    }
  }

  /// Creates a new stadium and returns its id.  Optionally accepts a list
  /// of maps with keys 'name' and 'data' (Uint8List) representing the
  /// uploaded plans.  The number of maps should not exceed 5.
  static Future<int> createStadium({
    required String name,
    String? address,
    String? defaultLeader,
    String? defaultLeaderPhone,
    String? defaultLeaderEmail,
    String? defaultClub,
    List<Map<String, dynamic>>? plans,
  }) async {
    final conn = await _connect();
    try {
      final result = await conn.query(
        'INSERT INTO stadiums (name, address, default_leader, default_leader_phone, default_leader_email, default_club) VALUES (?, ?, ?, ?, ?, ?)',
        [name, address, defaultLeader, defaultLeaderPhone, defaultLeaderEmail, defaultClub],
      );
      final stadiumId = result.insertId ?? 0;
      if (plans != null) {
        for (final plan in plans) {
          // Ensure binary data is stored as Uint8List to allow proper
          // retrieval from the database.  Without this, mysql1 may
          // serialize lists into strings which cannot be decoded as
          // images later.
          final String originalName = plan['name'] as String;
          final dynamic d = plan['data'];
          Uint8List bytes;
          if (d is Uint8List) {
            bytes = d;
          } else if (d is List<int>) {
            bytes = Uint8List.fromList(d);
          } else {
            throw ArgumentError('Invalid plan data type');
          }
          // Attempt to store the file on disk.  If this fails, fall back
          // to a base64 representation so that the plan is not lost.
          String? savedPath;
          try {
            savedPath = await uploadPlanFile(bytes, originalName);
          } catch (_) {
            savedPath = null;
          }
          // Determine the data to store in the database.  When a local
          // file is saved, use its relative path (e.g. "uploads/1234_name.pdf").
          // Relative paths are resolved against the current working
          // directory when loading the file later.  If the file cannot
          // be saved, fall back to a base64 encoded representation.
          late final String dataToStore;
          if (savedPath != null && savedPath.isNotEmpty) {
            dataToStore = savedPath;
          } else {
            final String base64Str = base64.encode(bytes);
            dataToStore = base64Str;
          }
          // Insert the new plan into the stadium_maps table and capture its
          // insert id.  This id is used to associate a locally stored
          // file path with the corresponding database record so that
          // subsequent reads can bypass the database when loading
          // previews.
          final resultMap = await conn.query(
            'INSERT INTO stadium_maps (stadium_id, map_name, map_data) VALUES (?, ?, ?)',
            [stadiumId, originalName, dataToStore],
          );
          final int? insertedId = resultMap.insertId;
          // If a local file was successfully saved, record its absolute
          // path in the in-memory cache keyed by the newly inserted id.  This
          // allows the UI to display it immediately without reading
          // from the database.  Ignore cases where no local file exists.
          if (insertedId != null && savedPath != null && savedPath.isNotEmpty) {
            _localMapPaths[insertedId] = savedPath;
          }
        }
      }
      return stadiumId;
    } finally {
      await conn.close();
    }
  }

  /// Updates an existing stadium's basic fields (not plans).  To update
  /// plans, call [addStadiumMap] and [deleteStadiumMap].
  static Future<void> updateStadium({
    required int id,
    required String name,
    String? address,
    String? defaultLeader,
    String? defaultLeaderPhone,
    String? defaultLeaderEmail,
    String? defaultClub,
  }) async {
    final conn = await _connect();
    try {
      await conn.query(
        'UPDATE stadiums SET name = ?, address = ?, default_leader = ?, default_leader_phone = ?, default_leader_email = ?, default_club = ? WHERE id = ?',
        [name, address, defaultLeader, defaultLeaderPhone, defaultLeaderEmail, defaultClub, id],
      );
    } finally {
      await conn.close();
    }
  }

  /// Deletes a stadium and all its associated maps.
  static Future<void> deleteStadium(int id) async {
    final conn = await _connect();
    try {
      await conn.query('DELETE FROM stadium_maps WHERE stadium_id = ?', [id]);
      await conn.query('DELETE FROM stadiums WHERE id = ?', [id]);
    } finally {
      await conn.close();
    }
  }

  /// Retrieves all maps associated with a stadium.  Each map returned
  /// contains id, map_name and map_data (binary).  Use this to display
  /// or manage existing plans.
  static Future<List<Map<String, dynamic>>> getStadiumMaps(int stadiumId) async {
    final conn = await _connect();
    try {
      final results = await conn.query(
        'SELECT id, map_name, map_data FROM stadium_maps WHERE stadium_id = ?',
        [stadiumId],
      );
      final maps = <Map<String, dynamic>>[];
      for (final row in results) {
        // rawData holds either a URL string, a file path (relative or absolute),
        // or base64/binary data.  We defer its interpretation until after
        // consulting the in‑memory cache of locally stored files.
        final dynamic rawData = row['map_data'];
        Uint8List? data;
        String? url;
        String? filePath;

        // Check for a locally cached file path first.  When a plan
        // was uploaded during this session the [createStadium] or
        // [addStadiumMap] methods will have recorded the returned
        // relative path in [_localMapPaths] keyed by the newly
        // inserted map id.  Using this cache avoids needing to
        // interpret rawData or query the database for a path.
        final int mapId = row['id'] as int;
        if (_localMapPaths.containsKey(mapId)) {
          filePath = _localMapPaths[mapId];
        }

        // If no local cache entry exists, interpret the raw data.  The
        // mysql1 driver returns LONGTEXT columns as Uint8List rather
        // than a String, so we decode it before examining its
        // contents.  Once a string is obtained we decide whether it
        // represents a remote URL, a file path or base64 encoded data.
        if (filePath == null) {
          String? stringValue;
          if (rawData is String) {
            stringValue = rawData;
          } else if (rawData is Uint8List) {
            stringValue = utf8.decode(rawData, allowMalformed: true);
          } else if (rawData is List<int>) {
            stringValue = utf8.decode(rawData, allowMalformed: true);
          }
          if (stringValue != null) {
            final str = stringValue;
            if (str.startsWith('http')) {
              // Remote URL returned by a server upload script; keep as URL.
              url = str;
            } else {
              // Heuristically determine whether the value is base64 or a file path.
              // If the string contains typical path separators (slash, backslash or
              // colon) we treat it as a path.  Otherwise we attempt to decode it
              // as base64; if decoding fails, we also treat it as a path.  This
              // handles absolute paths stored by uploadPlanFile as well as the
              // original base64 storage format.
              if (str.contains('/') || str.contains('\\') || str.contains(':')) {
                filePath = str;
              } else {
                try {
                  final decodedBytes = base64.decode(str);
                  data = Uint8List.fromList(decodedBytes);
                } catch (_) {
                  filePath = str;
                }
              }
            }
          }
        }

        // If a file system path was stored in the database, resolve it to
        // an absolute path and attempt to load image bytes for preview.
        // Relative paths (e.g. "upload/filename.png") are resolved against
        // the current working directory.  If the file exists and the
        // corresponding map name is not a PDF, its bytes are loaded
        // into [data] for preview.  The absolute path is then stored
        // back into [filePath] so that the UI can still access PDF
        // documents via File(path).
        if (filePath != null) {
          // Correct legacy singular 'upload' folder names to the plural
          // 'uploads'.  Some older records may contain a path like
          // ".../upload/..." or "...\\upload\\...".  Since the
          // application saves files into the "uploads" directory, swap
          // out the folder name when necessary before resolving the path.
          if (filePath.contains('/upload/')) {
            filePath = filePath.replaceFirst('/upload/', '/uploads/');
          }
          if (filePath.contains('\\upload\\')) {
            filePath = filePath.replaceFirst('\\upload\\', '\\uploads\\');
          }
          // Resolve relative paths to absolute paths.  When a path
          // begins with `assets/` on Windows, it refers to a file
          // stored within the Flutter debug assets directory
          // (build/windows/x64/runner/Debug/data/flutter_assets).
          String resolvedPath = filePath;
          final testFile = File(resolvedPath);
          if (!testFile.isAbsolute) {
            // Determine if the path is within the Flutter assets
            if (filePath.startsWith('assets/') || filePath.startsWith('assets\\')) {
              final Directory debugAssetsBase = Directory('${Directory.current.path}/build/windows/x64/runner/Debug/data/flutter_assets');
              resolvedPath = '${debugAssetsBase.path}/$filePath';
            } else {
              resolvedPath = '${Directory.current.path}/$filePath';
            }
          }
          try {
            final resolvedFile = File(resolvedPath);
            if (await resolvedFile.exists()) {
              // Update filePath to the absolute path so consumers can
              // locate the file correctly.
              filePath = resolvedFile.path;
              // Only load image data for non-PDF files; PDFs will still
              // be represented by an icon in the UI.
              final String mapName = (row['map_name'] as String).toLowerCase();
              if (!mapName.endsWith('.pdf')) {
                final bytes = await resolvedFile.readAsBytes();
                data ??= Uint8List.fromList(bytes);
              }
            }
          } catch (_) {
            // Ignore errors while resolving or reading the file.  The
            // UI will fall back to showing an icon if no preview is
            // available.
          }
        }

        // Emit a debug log to help diagnose why a preview may not appear.
        // The log shows the name of the map, whether binary data was loaded,
        // the resolved file path (if any) and URL (if any).  This can be
        // viewed in the console when running `flutter run --verbose`.
        try {
          // Use double quotes around the log string to avoid mixing with single
          // quotes used inside the interpolation (e.g. row['id']).
          print("[DbService.getStadiumMaps] id: ${row['id']}, name: ${row['map_name']}, hasData: ${data != null}, path: $filePath, url: $url");
        } catch (_) {}
        maps.add({
          'id': row['id'] as int,
          'map_name': row['map_name'] as String,
          'map_data': data,
          'map_url': url,
          'map_path': filePath,
        });
      }
      return maps;
    } finally {
      await conn.close();
    }
  }

  /// Adds a new map to a stadium.  Takes the binary [data] and a human
  /// readable [name].  Returns the id of the inserted map.
  static Future<int> addStadiumMap({
    required int stadiumId,
    required String name,
    required List<int> data,
  }) async {
    final conn = await _connect();
    try {
      // Convert the incoming list to a Uint8List to allow for
      // base64 encoding if the remote upload fails.  This mirrors
      // the behaviour in createStadium, where a fallback to a
      // base64 string ensures that the map is still stored in the
      // database even if the file cannot be uploaded to the remote
      // server.  Without this, the caller would silently lose the
      // uploaded file and the UI would show "Kein Vorschau verfügbar".
      final Uint8List bytes = Uint8List.fromList(data);
      // Attempt to persist the map to disk.  Fallback to base64
      // encoding if saving fails.  The uploadPlanFile method stores
      // files in the app's documents directory and returns a
      // relative path.  Convert this relative path into an
      // absolute path so that the file can be located across
      // sessions.
      String? savedPath;
      try {
        savedPath = await uploadPlanFile(bytes, name);
      } catch (_) {
        savedPath = null;
      }
      // Determine the data to store in the database.  When a local
      // file is saved, use its relative path.  Otherwise, fall back
      // to base64 encoding.
      late final String dataToStore;
      if (savedPath != null && savedPath.isNotEmpty) {
        dataToStore = savedPath;
      } else {
        final String base64Str = base64.encode(bytes);
        dataToStore = base64Str;
      }
      // Insert the new map and capture its id.  Use the id to
      // associate the saved file path with this record so the UI can
      // display it without querying the database again.  When
      // savedPath is null (fallback to base64) the map is not
      // recorded in the cache.
      final result = await conn.query(
        'INSERT INTO stadium_maps (stadium_id, map_name, map_data) VALUES (?, ?, ?)',
        [stadiumId, name, dataToStore],
      );
      final int? insertedId = result.insertId;
      if (insertedId != null && savedPath != null && savedPath.isNotEmpty) {
        _localMapPaths[insertedId] = savedPath;
      }
      return insertedId ?? 0;
    } finally {
      await conn.close();
    }
  }

  /// Deletes an existing stadium map by id.
  static Future<void> deleteStadiumMap(int mapId) async {
    final conn = await _connect();
    try {
      await conn.query('DELETE FROM stadium_maps WHERE id = ?', [mapId]);
    } finally {
      await conn.close();
    }
  }

  // ------------------------------------------------------------------------
  // File upload helper

  /// Persists a stadium plan file to the local filesystem.
  ///
  /// In the original implementation of PSS, this method uploaded the file to
  /// a remote PHP script (`upload.php`) and returned the URL of the saved
  /// file.  However, when the `path_provider` plugin is unavailable or
  /// network connectivity is unreliable, storing uploads locally ensures
  /// that user‑provided documents are never lost.  This implementation
  /// writes the bytes to a `uploads` folder in the project root and
  /// returns a relative path (e.g. `uploads/1234_plan.png`).  Callers
  /// should store this string in the database and treat it either as a
  /// file path (if it contains path separators) or base64 data (if not).
  static Future<String?> uploadPlanFile(List<int> bytes, String filename) async {
    // Persist uploaded files into a local `uploads` directory at the
    // project root (sitting alongside `lib` and `assets`).  The
    // directory is created on demand.  This method writes the
    // bytes to disk and returns a **relative** path (e.g. `uploads/1234.png`).
    // Storing relative paths rather than absolute ones makes the
    // database entries portable across different machines or build
    // environments; callers can resolve the relative path against
    // their current working directory when loading the file.
    try {
      final Directory currentDir = Directory.current;
      // Persist user uploads into the `uploads` directory at the project
      // root.  This path is relative to the application's current
      // working directory (e.g. PSS/uploads).  If the folder does not
      // yet exist it will be created recursively.
      final Directory uploadDir = Directory('${currentDir.path}/uploads');
      if (!await uploadDir.exists()) {
        await uploadDir.create(recursive: true);
      }
      // Sanitize filename: allow only alphanumeric characters, underscores,
      // dashes and dots to avoid invalid file names and path traversal.
      final sanitized = filename.replaceAll(RegExp(r'[^A-Za-z0-9_\.\-]'), '_');
      // Prefix the file name with a timestamp to ensure uniqueness.
      final uniqueName = '${DateTime.now().millisecondsSinceEpoch}_$sanitized';
      final filePath = '${uploadDir.path}/$uniqueName';
      final file = File(filePath);
      await file.writeAsBytes(bytes, flush: true);
      // Return the absolute path (e.g. '/path/to/project/uploads/12345_map.png')
      // of the saved file rather than a relative path.  Using an absolute
      // path ensures that the file can be located reliably across app
      // restarts and when the working directory changes (such as when
      // launching a compiled Windows build).  The relative path approach
      // caused issues because `Directory.current` may differ between runs.
      final String absolutePath = filePath;
      // Emit a debug message when running in debug mode so developers can
      // verify where the file was written.  These print statements will
      // appear in the console when running `flutter run` and can help
      // diagnose issues where the preview is not found.
      try {
        // Use double quotes for the debug string to avoid conflicts with single
        // quotes inside interpolations.  This log helps verify where files are saved.
        print("[DbService.uploadPlanFile] Saved $filename to $absolutePath");
      } catch (_) {}
      return absolutePath;
    } catch (e) {
      // Writing failed; return null on error
    }
    return null;
  }
}