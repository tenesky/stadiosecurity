import 'package:flutter/material.dart';
import 'pages/login_page.dart';
import 'pages/splash_screen.dart';

/// Entry point for the PSS Security application.
///
/// The application defines a simple theme and shows the [LoginPage] as
/// the initial route.  Once the user has authenticated successfully
/// they will be navigated to the home screen (see login_page.dart).
Future<void> main() async {
  // Ensure that Flutter engine bindings are initialised before
  // interacting with plugins.  This is required when using
  // asynchronous initialisation such as the path_provider plugin
  // used for storing uploaded files on disk.
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  static const Color primaryBlue = Color(0xFF5a93a8);
  static const Color white = Color(0xFFFFFFFF);
  static const Color headerColor = Color(0xFF78B1C6);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'PSS Security',
      theme: ThemeData(
        // Set the primary and background colours for the app.  On
        // modern Flutter versions it is sufficient to set the
        // `colorScheme` directly without building a custom swatch.
        colorScheme: ColorScheme.light(
          primary: primaryBlue,
          onPrimary: white,
          background: white,
        ),
        appBarTheme: const AppBarTheme(
          backgroundColor: headerColor,
          foregroundColor: white,
        ),
      ),
      home: const SplashScreen(),
    );
  }
}